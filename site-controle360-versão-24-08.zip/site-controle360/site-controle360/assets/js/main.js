/* main.js - Funções de interação do site Controle 360 */

/* ========= MENU RESPONSIVO ========= */
document.addEventListener("DOMContentLoaded", () => {
  const nav = document.querySelector("header nav");
  const menuBtn = document.createElement("button");
  menuBtn.textContent = "☰";
  menuBtn.classList.add("menu-toggle");
  nav.parentNode.insertBefore(menuBtn, nav);

  menuBtn.addEventListener("click", () => {
    nav.classList.toggle("ativo");
  });
});

/* ========= FORMULÁRIO DE CONTATO ========= */
const form = document.querySelector("#contato-formulario form");
if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const nome = form.nome.value.trim();
    const email = form.email.value.trim();
    const assunto = form.assunto.value.trim();
    const mensagem = form.mensagem.value.trim();

    // Validação simples
    if (!nome || !email || !mensagem) {
      alert("Preencha todos os campos obrigatórios!");
      return;
    }

    const emailRegex = /^[^@]+@[^@]+\.[^@]+$/;
    if (!emailRegex.test(email)) {
      alert("Digite um e-mail válido!");
      return;
    }

    // Confirmação
    alert("Sua mensagem foi enviada com sucesso!");

    // Redirecionar para WhatsApp
    const texto = encodeURIComponent(
      `Olá! Sou ${nome}. Assunto: ${assunto}. Mensagem: ${mensagem}. Meu e-mail: ${email}`
    );
    window.open(`https://wa.me/5519999557083?text=${texto}`, "_blank");
  });
}

/* ========= GALERIA DE PORTFÓLIO ========= */
const imagens = document.querySelectorAll(".galeria-portfolio img");
if (imagens.length > 0) {
  const modal = document.createElement("div");
  modal.classList.add("modal");
  modal.innerHTML = `
    <span class="fechar">&times;</span>
    <img class="modal-img" src="" alt="">
    <button class="anterior">◀</button>
    <button class="proximo">▶</button>
  `;
  document.body.appendChild(modal);

  const modalImg = modal.querySelector(".modal-img");
  let indexAtual = 0;

  function abrirModal(i) {
    indexAtual = i;
    modalImg.src = imagens[i].src;
    modal.style.display = "flex";
  }

  imagens.forEach((img, i) => {
    img.addEventListener("click", () => abrirModal(i));
  });

  modal.querySelector(".fechar").onclick = () => (modal.style.display = "none");
  modal.querySelector(".anterior").onclick = () => {
    indexAtual = (indexAtual - 1 + imagens.length) % imagens.length;
    modalImg.src = imagens[indexAtual].src;
  };
  modal.querySelector(".proximo").onclick = () => {
    indexAtual = (indexAtual + 1) % imagens.length;
    modalImg.src = imagens[indexAtual].src;
  };
}

/* ========= DEPOIMENTOS AUTOMÁTICOS ========= */
const depoimentos = document.querySelectorAll(".depoimento-card");
if (depoimentos.length > 0) {
  let atual = 0;
  function mostrarDepoimento(i) {
    depoimentos.forEach((dep, idx) => {
      dep.style.display = idx === i ? "block" : "none";
    });
  }
  mostrarDepoimento(atual);
  setInterval(() => {
    atual = (atual + 1) % depoimentos.length;
    mostrarDepoimento(atual);
  }, 30000); // 30 segundos
}

/* ========= BOTÃO VOLTAR AO TOPO ========= */
const btnTopo = document.createElement("button");
btnTopo.textContent = "↑";
btnTopo.classList.add("btn-topo");
document.body.appendChild(btnTopo);

window.addEventListener("scroll", () => {
  if (window.scrollY > 300) {
    btnTopo.style.display = "block";
  } else {
    btnTopo.style.display = "none";
  }
});

btnTopo.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});